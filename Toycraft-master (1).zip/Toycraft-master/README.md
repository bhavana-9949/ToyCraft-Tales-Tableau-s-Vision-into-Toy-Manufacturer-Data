# ToyCraft-Tales-Tableau-s-Vision-Into-Toy-Manufacturer-Data
Welcome to ToyCraft Tales, a data visualization project that dives into the vibrant world of toy manufacturing using the power of Tableau. This project uncovers hidden patterns, market trends, and consumer preferences through interactive and insightful dashboards.

Homepage![Homepage](https://github.com/user-attachments/assets/2c299805-6e3c-42d8-b99b-69ada04c84c2)
Aboutpage![Aboutpage](https://github.com/user-attachments/assets/a11f6755-ced5-47a6-8371-fcb53b6b210e)
Dahboardpage![Dashboardpage](https://github.com/user-attachments/assets/368d28b3-e74c-49d4-b49e-bb3769c7689a)
Storypage![Storypage](https://github.com/user-attachments/assets/9fc5c90c-5d30-40ec-8f5e-1bdf590e47db)
contactpage![Contact](https://github.com/user-attachments/assets/0f5fdff6-630c-4fb0-8803-396de18c5e5d)
